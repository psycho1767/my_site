const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");
const tableRoutes = require("./routes/tableRoutes");

const app = express();
const port = 3000;

// اتصال به دیتابیس MongoDB
mongoose.connect("mongodb://localhost:27017/yourDatabaseName", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(cors());
app.use(bodyParser.json());

// سرو فایل‌های استاتیک
app.use(express.static(path.join(__dirname, "../client")));

app.use("/api", tableRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
