const express = require("express");
const Table = require("../models/tableModel");

const router = express.Router();

router.post("/saveTable", async (req, res) => {
  const tableData = req.body;

  try {
    const newTable = new Table(tableData);
    await newTable.save();
    res.status(200).send("Table saved successfully");
  } catch (error) {
    console.error("Error saving table:", error);
    res.status(500).send("Error saving table");
  }
});

router.get("/tables", async (req, res) => {
  try {
    const tables = await Table.find();
    res.status(200).json(tables);
  } catch (error) {
    console.error("Error fetching tables:", error);
    res.status(500).send("Error fetching tables");
  }
});

router.get("/tables/:id", async (req, res) => {
  try {
    const table = await Table.findById(req.params.id);
    if (table) {
      res.status(200).json(table);
    } else {
      res.status(404).send("Table not found");
    }
  } catch (error) {
    console.error("Error fetching table:", error);
    res.status(500).send("Error fetching table");
  }
});

router.delete("/tables/:id", async (req, res) => {
  try {
    await Table.findByIdAndDelete(req.params.id);
    res.status(200).send("Table deleted successfully");
  } catch (error) {
    console.error("Error deleting table:", error);
    res.status(500).send("Error deleting table");
  }
});

module.exports = router;
