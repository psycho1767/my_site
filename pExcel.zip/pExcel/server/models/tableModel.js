const mongoose = require("mongoose");

const TableSchema = new mongoose.Schema({
  name: String,
  rows: Array,
  grandTotal: Number,
});

module.exports = mongoose.model("Table", TableSchema);
