document.addEventListener("DOMContentLoaded", () => {
  const toggleButton = document.querySelector(".toggle-button");
  const navbarLinks = document.querySelector(".navbar-links");

  toggleButton.addEventListener("click", () => {
    navbarLinks.classList.toggle("active");
  });

  window.addEventListener("hashchange", () => {
    loadContent();
  });

  loadContent();

  const loginForm = document.getElementById("loginForm");
  loginForm.addEventListener("submit", handleLogin);
  checkLoginStatus();
});

function loadContent() {
  const content = document.getElementById("content");
  const hash = window.location.hash.substring(1);

  if (hash === "tables") {
    loadTables();
  } else if (hash.startsWith("view/")) {
    const tableId = hash.split("/")[1];
    loadTableById(tableId);
  } else {
    loadHome();
  }
}

function loadHome() {
  const content = document.getElementById("content");
  content.innerHTML = `
      <div>
          <input type="text" id="tableName" class="table-name" placeholder="نام جدول را وارد کنید" ${
            !isLoggedIn() ? "disabled" : ""
          }>
      </div>
      <div class="table-container">
          <table>
              <thead>
                  <tr>
                      <th>ردیف</th>
                      <th>نام جنس</th>
                      <th>تعداد</th>
                      <th>قیمت جنس</th>
                      <th>قیمت نهایی</th>
                  </tr>
              </thead>
              <tbody id="tableBody">
                  <tr>
                      <td>1</td>
                      <td><input type="text" class="item-name" ${
                        !isLoggedIn() ? "disabled" : ""
                      }></td>
                      <td><input type="number" class="item-quantity" oninput="calculateFinalPrice(this)" ${
                        !isLoggedIn() ? "disabled" : ""
                      }></td>
                      <td><input type="number" class="item-price" oninput="calculateFinalPrice(this)" ${
                        !isLoggedIn() ? "disabled" : ""
                      }></td>
                      <td class="item-total">0</td>
                  </tr>
              </tbody>
              <tfoot>
                  <tr>
                      <td colspan="4" class="total">جمع کل:</td>
                      <td id="grandTotal" class="total">0</td>
                  </tr>
              </tfoot>
          </table>
      </div>
      <button onclick="addRow()" ${
        !isLoggedIn() ? "disabled" : ""
      }>اضافه کردن ردیف</button>
      <button onclick="saveTable()" ${
        !isLoggedIn() ? "disabled" : ""
      }>ذخیره جدول</button>
  `;
}

function loadTables() {
  if (!isLoggedIn()) {
    alert("لطفا لاگین کنید.");
    return;
  }

  const content = document.getElementById("content");
  content.innerHTML = `<h2>جدول‌های من</h2><div id="tableList"></div>`;
  fetchTables();
}

function fetchTables() {
  fetch("http://localhost:3000/api/tables")
    .then((response) => response.json())
    .then((tables) => {
      const tableList = document.getElementById("tableList");
      tableList.innerHTML = "";
      tables.forEach((table) => {
        const tableItem = document.createElement("div");
        tableItem.className = "table-item";
        tableItem.innerHTML = `
                  ${table.name}
                  <button class="delete-button" onclick="deleteTable('${table._id}')">حذف</button>
                  <button class="view-button" onclick="location.hash='view/${table._id}'">مشاهده</button>
              `;
        tableItem.addEventListener("click", () => {
          loadTableDetails(table);
        });
        tableList.appendChild(tableItem);
      });
    })
    .catch((error) => {
      console.error("Error fetching tables:", error);
    });
}

function loadTableById(tableId) {
  fetch(`http://localhost:3000/api/tables/${tableId}`)
    .then((response) => response.json())
    .then((table) => {
      const content = document.getElementById("content");
      content.innerHTML = `
              <h2>${table.name}</h2>
              <div class="table-container">
                  <table>
                      <thead>
                          <tr>
                              <th>ردیف</th>
                              <th>نام جنس</th>
                              <th>تعداد</th>
                              <th>قیمت جنس</th>
                              <th>قیمت نهایی</th>
                          </tr>
                      </thead>
                      <tbody>
                          ${table.rows
                            .map(
                              (row, index) => `
                              <tr>
                                  <td>${index + 1}</td>
                                  <td>${row.name}</td>
                                  <td>${row.quantity}</td>
                                  <td>${row.price}</td>
                                  <td>${row.total}</td>
                              </tr>
                          `
                            )
                            .join("")}
                      </tbody>
                      <tfoot>
                          <tr>
                              <td colspan="4" class="total">جمع کل:</td>
                              <td class="total">${table.grandTotal}</td>
                          </tr>
                      </tfoot>
                  </table>
              </div>
          `;
    })
    .catch((error) => {
      console.error("Error fetching table:", error);
    });
}

function loadTableDetails(table) {
  const content = document.getElementById("content");
  content.innerHTML = `
      <h2>${table.name}</h2>
      <div class="table-container">
          <table>
              <thead>
                  <tr>
                      <th>ردیف</th>
                      <th>نام جنس</th>
                      <th>تعداد</th>
                      <th>قیمت جنس</th>
                      <th>قیمت نهایی</th>
                  </tr>
              </thead>
              <tbody>
                  ${table.rows
                    .map(
                      (row, index) => `
                      <tr>
                          <td>${index + 1}</td>
                          <td>${row.name}</td>
                          <td>${row.quantity}</td>
                          <td>${row.price}</td>
                          <td>${row.total}</td>
                      </tr>
                  `
                    )
                    .join("")}
              </tbody>
              <tfoot>
                  <tr>
                      <td colspan="4" class="total">جمع کل:</td>
                      <td class="total">${table.grandTotal}</td>
                  </tr>
              </tfoot>
          </table>
      </div>
  `;
}

function calculateFinalPrice(element) {
  const row = element.parentElement.parentElement;
  const quantity = row.querySelector(".item-quantity").value;
  const price = row.querySelector(".item-price").value;
  const totalCell = row.querySelector(".item-total");

  const total = quantity * price;
  totalCell.textContent = total;

  calculateGrandTotal();
}

function calculateGrandTotal() {
  const totals = document.querySelectorAll(".item-total");
  let grandTotal = 0;

  totals.forEach((total) => {
    grandTotal += parseFloat(total.textContent);
  });

  document.getElementById("grandTotal").textContent = grandTotal;
}

function addRow() {
  const tableBody = document.getElementById("tableBody");
  const rowCount = tableBody.rows.length + 1;

  const row = document.createElement("tr");
  row.innerHTML = `
      <td>${rowCount}</td>
      <td><input type="text" class="item-name" ${
        !isLoggedIn() ? "disabled" : ""
      }></td>
      <td><input type="number" class="item-quantity" oninput="calculateFinalPrice(this)" ${
        !isLoggedIn() ? "disabled" : ""
      }></td>
      <td><input type="number" class="item-price" oninput="calculateFinalPrice(this)" ${
        !isLoggedIn() ? "disabled" : ""
      }></td>
      <td class="item-total">0</td>
  `;

  tableBody.appendChild(row);
}

async function saveTable() {
  const tableName = document.getElementById("tableName").value;
  if (!tableName) {
    alert("لطفا نام جدول را وارد کنید");
    return;
  }

  const rows = document.querySelectorAll("#tableBody tr");
  const data = Array.from(rows).map((row) => {
    return {
      name: row.querySelector(".item-name").value,
      quantity: row.querySelector(".item-quantity").value,
      price: row.querySelector(".item-price").value,
      total: row.querySelector(".item-total").textContent,
    };
  });

  const tableData = {
    name: tableName,
    rows: data,
    grandTotal: document.getElementById("grandTotal").textContent,
  };

  try {
    const response = await fetch("http://localhost:3000/api/saveTable", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(tableData),
    });

    if (response.ok) {
      alert("جدول با موفقیت ذخیره شد");
    } else {
      alert("خطا در ذخیره جدول");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("خطا در ذخیره جدول");
  }
}

async function deleteTable(tableId) {
  try {
    const response = await fetch(
      `http://localhost:3000/api/tables/${tableId}`,
      {
        method: "DELETE",
      }
    );

    if (response.ok) {
      alert("جدول با موفقیت حذف شد");
      fetchTables(); // به‌روزرسانی لیست جداول
    } else {
      alert("خطا در حذف جدول");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("خطا در حذف جدول");
  }
}

function showLoginModal() {
  document.getElementById("loginModal").style.display = "block";
}

function closeLoginModal() {
  document.getElementById("loginModal").style.display = "none";
}

function handleLogin(event) {
  event.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (username === "payman" && password === "123456789") {
    setCookie("loggedIn", "true", 7);
    closeLoginModal();
    loadContent();
  } else {
    document.getElementById("loginError").textContent =
      "نام کاربری یا رمز عبور اشتباه است";
  }
}

function checkLoginStatus() {
  if (getCookie("loggedIn") === "true") {
    loadContent();
  }
}

function isLoggedIn() {
  return getCookie("loggedIn") === "true";
}

function setCookie(name, value, days) {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
  const expires = "expires=" + date.toUTCString();
  document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

function getCookie(name) {
  const cname = name + "=";
  const decodedCookie = decodeURIComponent(document.cookie);
  const ca = decodedCookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(cname) == 0) {
      return c.substring(cname.length, c.length);
    }
  }
  return "";
}
